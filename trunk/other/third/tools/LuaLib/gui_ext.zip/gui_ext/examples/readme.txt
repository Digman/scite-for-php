These are some examples of how to use SciTE-GUI.

You will have to put require('gui') in your startup script! gui.dll should sit next to
SciTE.exe.

Note that url.lua and edit_colour.lua require extman, although they are easy to modify
to work with stock SciTE.

If you are using extman, then drop them into your scite_lua directory; otherwise, put
them next to your startup script and require() them.