#ifndef _TWL_DIB_H
#define _TWL_DIB_H
#include "twl.h"
#ifndef DIB_DEFINED
typedef void* PCDIB;
#else
typedef CDIB* PCDIB;
#endif
class TDIB
{
	PCDIB m_impl;
public:
	TDIB();
	TDIB(char* file);
	~TDIB();
	int width();
	int height();
	bool load(char* file);
	void draw(TDC& dc);
	void stretch(TDC& dc,const Rect& rt);
	void stretch(TDC& dc,const Rect& dest, const Rect& src);
};
#endif