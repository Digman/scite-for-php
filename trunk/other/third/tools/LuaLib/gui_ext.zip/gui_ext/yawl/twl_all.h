// TWL_ALL.H
// The whole kaboodle
#ifndef __TWL_ALL_H
#define __TWL_ALL_H
#include "twl.h"
#include "twl_layout.h"
#include "twl_dialogs.h"
#include "twl_modal.h"
#include "twl_ini.h"
#include "twl_automenu.h"
#include "twl_comctls.h"
#endif