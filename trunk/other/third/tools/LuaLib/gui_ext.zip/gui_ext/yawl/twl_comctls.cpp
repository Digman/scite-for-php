// twl_comctls.cpp
#include <windows.h>
#include <commctrl.h>
#include "twl_comctls.h"

static TBBUTTON ttbtn;

TToolBar::TToolBar(TWin* parent, int id)
        : TControl(parent,TOOLBARCLASSNAME,"",id,CCS_TOP  | TBSTYLE_FLAT)
{
      send_msg(TB_BUTTONSTRUCTSIZE,sizeof(TBBUTTON),0);
      send_msg(TB_LOADIMAGES,IDB_STD_SMALL_COLOR,(long)HINST_COMMCTRL);
      //send_msg(TB_SETBUTTONSIZE,0,MAKELONG(18,16));
}


void TToolBar::add_button(pchar caption, int image_id, int cmd_id)
{
        ttbtn.iBitmap = image_id;
        ttbtn.idCommand = cmd_id;
        ttbtn.fsState = TBSTATE_ENABLED;
        ttbtn.fsStyle = TBSTYLE_BUTTON;
        if (caption) {
            // this caption must have have a double \0
          char buff[100];
          lstrcpy(buff,caption);
          buff[lstrlen(buff)+1] = '\0';
          ttbtn.iString = send_msg(TB_ADDSTRING,0,(long)buff);
        } else
          ttbtn.iString = -1;
        send_msg(TB_ADDBUTTONS,1,(long)&ttbtn);
}

void TToolBar::load_image()
{
  
}

void TToolBar::generate()
{
       add_button(0,STD_FILEOPEN,100);
       add_button(0,STD_FILESAVE,101);
       add_button(0,STD_COPY,102);
       send_msg(TB_AUTOSIZE,0);
}

