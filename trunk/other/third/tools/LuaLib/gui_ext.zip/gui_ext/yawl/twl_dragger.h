#ifndef _TWL_DRAGGER_H
#define _TWL_DRAGGER_H
#include <math.h>
class TDragger
{
protected:
	TEventWindow* m_window;
	enum MouseState {UP,DOWN,DRAG};
	MouseState m_state;
	Rect m_rt;

public:
  TDragger(TEventWindow* win)
	  : m_window(win),m_state(UP)
  {}

  void mouse_down(Point& pt)
  {
	m_rt.left = pt.x;
	m_rt.top = pt.y;
	m_state = DOWN;
  }

  virtual void draw_selection(TDC& dc, const Rect& rt)
  {
	  dc.draw_focus_rect(rt);	  
  }

  virtual void modify_rect(Point& pt)
  {
	m_rt.right = pt.x;
	m_rt.bottom = pt.y;
  }

  static double max(double x, double y)
  {
	  return x > y ? x : y;
  }

  virtual void normalize_rect(Rect& rt)
  {
	int ext = max(rt.width(), rt.height());
	rt.right = rt.left + ext;
	rt.bottom = rt.top + ext;
  }

  virtual void select_window()
  {
	normalize_rect(m_rt);
	m_window->on_select(m_rt);
  }

  void mouse_move(Point& pt)
  {
	  if (m_state == DOWN && fabs(m_rt.left - pt.x) + fabs(m_rt.top - pt.y) > 10) {
		m_state = DRAG;
		TClientDC dc(m_window);
		modify_rect(pt);
		draw_selection(dc,m_rt);
	  } else
	  if (m_state == DRAG) {
		TClientDC dc(m_window);
		draw_selection(dc,m_rt);
		modify_rect(pt);
		draw_selection(dc,m_rt);
	  }
  }

  void mouse_up(Point& pt)
  {
	  if (m_state == DRAG) {
		  TClientDC dc(m_window);		  
		  draw_selection(dc,m_rt);
		  select_window();
	  }
	  m_state = UP;
  }


};

class TLineDragger : public TDragger {
public:
	TLineDragger(TEventWindow* win)
		: TDragger(win)
	{}

  virtual void normalize_rect(Rect& rt)
  { }


  virtual void draw_selection(TDC& dc, const Rect& rt)
  {
	dc.xor_pen(true);
	dc.set_colour(1,1,1);
	dc.draw_line(rt.corner(Rect::TOP_LEFT), rt.corner(Rect::BOTTOM_RIGHT));	
	dc.xor_pen(false);
  }

};

#endif
