// TWL_AUTOMENU.H
#ifndef __TWL_AUTOMENU_H
#define __TWL_AUTOMENU_H
#include "twl.h"
#include "twl_ini.h"

EXPORT char *i2a(int i);

class EXPORT AutoMenu {
private:
  IniBase *m_ini;
  TEventWindow *m_form;
  void* m_items;
  int m_popup_idx;
  const char *m_section;
  int m_max_items,m_id,m_start_id;
  char *m_curr_file;
  long m_curr_pos; 
  void* m_curr_data;
  bool m_files_overflow;
  bool  m_strip_cwd;
  const char* m_cwd;
protected:
  int iterate_menu(int op, void* target=NULL);
  void add_item_to_list(pchar filename, void *data,bool at_end);
public:
  AutoMenu(TEventWindow *form, IniBase *ini, int popup_idx, pchar section, int max_items);
  int  count();
  int handle(int id);  
  bool match(pchar filename);
  bool select(int idx);
  bool remove(int idx);
  void rotate_items(bool forward);
  void add_item(pchar filename, void *data = NULL);  
  void read();
  void write();

  pchar current_file()           { return m_curr_file; }
  long  current_pos()            { return m_curr_pos;  }
  void *current_data()           { return m_curr_data; }
  int   cmd_id(int id)           { return m_start_id + id; }
  int   start_id()               { return m_start_id; }
  
  void current_dir(pchar dir);
  void strip_cwd(bool yesno);
  bool strip_cwd()                    { return m_strip_cwd; }


};
#endif
