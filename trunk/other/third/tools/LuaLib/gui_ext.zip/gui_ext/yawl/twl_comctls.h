#ifndef __TWL_COMCTLS_H
#define __TWL_COMCTLS_H
#include "twl_cntrls.h"
class EXPORT TToolBar: public TControl {
public:
    TToolBar(TWin* parent, int id);
    void add_button(pchar caption, int image_id, int cmd_id);
    void load_image();
    void generate();
};
#endif