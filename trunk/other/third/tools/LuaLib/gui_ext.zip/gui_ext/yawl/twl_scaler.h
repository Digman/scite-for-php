#ifndef __SCALER_H
#define __SCALER_H

class Scaler {
	double m_xmin,m_ymin,m_scl;
public:
	Scaler()
	{}

	Scaler(double xmin, double xmax, double ymin, double ymax)
	{
		set(xmin,xmax,ymin,ymax);
	}

	void set(double xmin, double xmax, double ymin, double ymax)
	{
		m_xmin = xmin;
		m_ymin = ymin;
		m_scl = (ymax - ymin)/(xmax - xmin);
	}

	double scale(double x)
	{
		return m_ymin + (x - m_xmin)*m_scl;
	}

	double unscale(double y)
	{
		return m_xmin + (y - m_ymin)/m_scl;
	}
};

class Scaler2D {
protected:
	Scaler m_horz, m_vert;
public:
	double mapx(double x)
	{
		return m_horz.scale(x);
	}

	double mapy(double y)
	{
		return m_vert.scale(y);
	}
};

// disable 'double' to 'long' warnings.
#pragma warning (disable: 4244)


template<class RectSrc, class RectDest>
class RectMapper : public Scaler2D {
public:
	void set(const RectSrc& src, const RectDest& dest)
	{
		m_horz.set(src.left,src.right,dest.left,dest.right);
		m_vert.set(src.top,src.bottom,dest.top,dest.bottom);
	}

	void map(const RectSrc& src, RectDest& dest)
	{
		dest.top = m_vert.scale(src.top);
		dest.bottom = m_vert.scale(src.bottom);
		dest.left = m_horz.scale(src.left);
		dest.right = m_horz.scale(src.right);
	}

	void unmap(const RectDest& src, RectSrc& dest)
	{
		dest.top = m_vert.unscale(src.top);
		dest.bottom = m_vert.unscale(src.bottom);
		dest.left = m_horz.unscale(src.left);
		dest.right = m_horz.unscale(src.right);
	}

};
#endif
